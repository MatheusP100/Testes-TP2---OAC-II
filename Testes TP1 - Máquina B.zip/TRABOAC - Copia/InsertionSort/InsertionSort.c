/* C Program to sort an array in ascending order using Insertion Sort */
#include <stdio.h>
#include <sys/time.h>
// #include <time.h>

/**
 * Returns the current time in microseconds.
 */
long getMicrotime(){
        struct timeval currentTime;
        gettimeofday(&currentTime, NULL);
        return currentTime.tv_sec * (int)1e6 + currentTime.tv_usec;
}

int main()
{
    int n=20000, i, j, temp;
    float arr[20001];
 
 	long begin = getMicrotime();
 	
    for (i = 0; i < n; i++)
    {
        scanf("%f", &arr[i]);
    }

    for (i = 1 ; i <= n - 1; i++)
    {
	    j = i;
            while ( j > 0 && arr[j-1] > arr[j])
            {	        
                temp     = arr[j];
                arr[j]   = arr[j-1];
                arr[j-1] = temp;
                j--;
            }
    }
    
    for (i = 0; i <= n - 1; i++)
    {
        printf("%.2f\n", arr[i]);
    }
    
    long end = getMicrotime();
    
    printf("Tempo para executar InsertionSort (us): %ld\n",(end-begin));
    return 0;
}
