/*
 * C Program to sort an array using Bubble Sort technique
 */
#include <stdio.h>
#include <sys/time.h>
// #include <time.h>

/**
 * Returns the current time in microseconds.
 */
long getMicrotime(){
        struct timeval currentTime;
        gettimeofday(&currentTime, NULL);
        return currentTime.tv_sec * (int)1e6 + currentTime.tv_usec;
}

void swap(float *a, float *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void bubblesort(float arr[], int size)
{
    int i, j;
    for (i = 0;  i < size; i++)
    {
        for (j = 0; j < size - i; j++)
        {
            if (arr[j] > arr[j+1])
                swap(&arr[j], &arr[j+1]);
 
        }
    }
}


int main()
{
    float array[20001];
    int i, size=20000;
    
    long begin = getMicrotime();

    for (i = 0; i < size; i++) {
        scanf("%f", &array[i]);
    }

    bubblesort(array, size);
 
    for (i = 0; i < size; i++) {
        printf("%.2f\n", array[i]);
    }
    
    long end = getMicrotime();

	printf("Tempo para executar BubbleSort (us): %ld\n",(end-begin));
    return 0;
}
