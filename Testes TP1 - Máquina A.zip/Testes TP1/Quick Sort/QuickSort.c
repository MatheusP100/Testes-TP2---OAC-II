/*
* C Program to Perform Quick Sort on a set of Entries from a File 
* using Recursion
*/
#include <stdio.h>
#include <sys/time.h>
// #include <time.h>

/**
 * Returns the current time in microseconds.
 */
long getMicrotime(){
        struct timeval currentTime;
        gettimeofday(&currentTime, NULL);
        return currentTime.tv_sec * (int)1e6 + currentTime.tv_usec;
}
 
void quicksort (float [], float, float);
 
int main()
{
    float list[20000];
    int size=20000, i;
    
    long begin = getMicrotime();
 
    for (i = 0; i < size; i++)
    {
        scanf("%f", &list[i]);
    } 
    
    quicksort(list, 0, size - 1);
    
    for (i = 0; i < size; i++)
    {
        printf("%.2f\n", list[i]);
    }
    
    long end = getMicrotime();
    printf("Tempo para executar QuickSort (us): %ld\n",(end-begin));
 
    return 0;
}
void quicksort(float list[], float low, float high)
{
    int pivot, i, j;
    float temp;
    
    if (low < high)
    {
        pivot = low;
        i = low;
        j = high;
        while (i < j) 
        {
            while (list[i] <= list[pivot] && i <= high)
            {
                i++;
            }
            while (list[j] > list[pivot] && j >= low)
            {
                j--;
            }
            if (i < j)
            {
                temp = list[i];
                list[i] = list[j];
                list[j] = temp;
            }
        }
        temp = list[j];
        list[j] = list[pivot];
        list[pivot] = temp;
        quicksort(list, low, j - 1);
        quicksort(list, j + 1, high);
    }
}
